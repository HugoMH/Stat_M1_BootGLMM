setwd('/DISQUE/0_Grenoble/0_Enseign/S2/Master_IS/TDs/Data/')

overdisp <- function(mod) {
  if(family(mod)$family=="binomial"){
    cat("Notice that overdispersion is irrelevant for Bernoulli (0/1) data
          See Skrondal and Rabe-Hesketh 2007 'Redundant Overdispersion Parameters in Multilevel Models for Categorical Responses' P3 for the demonstration.
          But it is important to avoid confusion between ungrouped Bernoulli (0/1) data that could be grouped as binomial data and Bernoulli (0/1) data.
          To measure overdispersion, you first have to group your data (when possible), and to refit your model on this grouped data.
    To get the meaning of ''grouped data'', see : http://stats.stackexchange.com/questions/144121/logistic-regression-bernoulli-vs-binomial-response-variables\n")
  }
  k <- attr(logLik(mod),"df") 
  if(is.null(k)){k <- mod@df.total-mod@df.residual}
  n <- length(fitted(mod)) 
  pearsonresid <- (1/(n-k)) * sum(resid(mod,"pearson")^2) 
  result <- c(pearsonresid)
  return(pearsonresid)}

# install.packages("DHARMa")
library(DHARMa)


ToHot = read.csv('./Suicide and Ambient Temperature.csv')
head(ToHot)

# ToHot$TemperatureDeviationFromMean = NA
# for(c in unique(ToHot$Country)){
#   w = which(ToHot$Country==c)
#   ToHot$TemperatureDeviationFromMean[w] = ToHot$Temperature[w] - mean(ToHot$Temperature[w])
# }

plot(ToHot$Suicide ~ ToHot$Temperature,col = as.numeric(as.factor(ToHot$Country)), log="y")
# plot(ToHot$Suicide ~ ToHot$TemperatureDeviationFromMean,col = as.numeric(as.factor(ToHot$Country)), log="y")

ToHot$Temperature2 = ToHot$Temperature^2
# ToHot$TemperatureDeviationFromMean2 = ToHot$TemperatureDeviationFromMean^2

plot(ToHot$Suicide ~ ToHot$Temperature2,col = as.numeric(as.factor(ToHot$Country)), log="y")
# plot(ToHot$Suicide ~ ToHot$TemperatureDeviationFromMean2,col = as.numeric(as.factor(ToHot$Country)), log="y")

# Normal models
Mnorm  = lm(Suicide ~ Temperature + Temperature2 + Country
            ,data = ToHot)
# Mnorm. = lm(Suicide ~ TemperatureDeviationFromMean + TemperatureDeviationFromMean2 + Country
#             ,data = ToHot)
plot(Mnorm ,1)
plot( simulateResiduals(Mnorm) )
# plot(Mnorm.,1)

### logNormal models -----
Mlog_norm  = lm(log(Suicide) ~ Temperature + Temperature2 + Country
            ,data = ToHot)
# Mlog_norm. = lm(log(Suicide) ~ TemperatureDeviationFromMean + TemperatureDeviationFromMean2 + Country
#             ,data = ToHot)
plot(Mlog_norm ,1)
# plot(Mlog_norm.,1)

plot(Mlog_norm ,2)
# plot(Mlog_norm.,2)
plot( simulateResiduals(Mlog_norm) )

shapiro.test(resid(Mlog_norm ))
# shapiro.test(resid(Mlog_norm.))

anova(Mlog_norm)
# anova(Mlog_norm.)

coef(Mlog_norm)[1:3]
# coef(Mlog_norm.)[1:3]

### boxcox models ----
bc <- MASS::boxcox(Mnorm,lambda=seq(-2,2,length=200))
lambda = bc$x[which.max(bc$y)]
z <- (ToHot$Suicide^lambda-1)/lambda
Mboxcox_norm  = lm(z ~ Temperature + Temperature2 + Country ,   data = ToHot)

# bc <- MASS::boxcox(Mnorm.,lambda=seq(-2,2,length=200))
# lambda = bc$x[which.max(bc$y)]
# z <- (ToHot$Suicide^lambda-1)/lambda

# Mboxcox_norm. = lm(z ~ TemperatureDeviationFromMean + TemperatureDeviationFromMean2 + Country ,   data = ToHot)

plot(Mboxcox_norm ,1)
# plot(Mboxcox_norm.,1)

plot(Mboxcox_norm ,2)
# plot(Mboxcox_norm.,2)

plot( simulateResiduals(Mboxcox_norm) )

shapiro.test(resid(Mboxcox_norm ))
# shapiro.test(resid(Mboxcox_norm.))

anova(Mboxcox_norm)
# anova(Mboxcox_norm.)

coef(Mboxcox_norm)[1:3]
# coef(Mboxcox_norm.)[1:3]

### GLM poisson -----
Mpoisson = glm(Suicide ~ Temperature + Temperature2 + Country
        ,data = ToHot, family = poisson(link = 'log'))
overdisp(Mpoisson)

plot( simulateResiduals(Mpoisson) )
summary(Mpoisson)

 MpoissonBoot = car::Boot(Mpoisson)
(MpoissonBoot = as.data.frame(confint(MpoissonBoot)))
 MpoissonBoot$overlap_0 = apply(MpoissonBoot,1,prod) < 0
 MpoissonBoot

### GLM quasipoisson -----
Mquasipoisson = glm(Suicide ~ Temperature + Temperature2 + Country
              ,data = ToHot, family = quasipoisson(link = 'log'))
summary(Mquasipoisson)
overdisp(Mquasipoisson)

plot( simulateResiduals(Mquasipoisson) )

summary(Mquasipoisson)

µ   = seq(min(EmpiricalMean_Variance), max(EmpiricalMean_Variance), length = 1000)
Var = µ+(µ^2)/Mnb$theta

par(mfrow=c(1,2))
for(log in c('', 'xy')){
  plot(EmpiricalMean_Variance, log = log)
  µ   = seq(min(EmpiricalMean_Variance), max(EmpiricalMean_Variance), length = 1000)
  Var = µ*overdisp(Mquasipoisson)
  points(µ,Var,type='l')
  abline(0,1)
}


### GLM negative binomial -----
#' Ici, nous allons ajuster un modèle negative binomial parce que nos données sont de type Poisson.
#' Pour des données de type binomial, si vous vouliez ajuster un modèle beta-binomial, vous pourriez utiliser la fonction `BBreg` du package `PROreg`.
#' Pour ce type de distribution, si votre modèle contient des effets aléatoires, conscidérez le package `aod` : aod::betabin() , aod::negbin()

Mnb = MASS::glm.nb(Suicide ~ Temperature + Temperature2 + Country
                   ,data = ToHot)
overdisp(Mnb)


summary(Mnb)
plot( simulateResiduals(Mnb) )

S = simulateResiduals(Mnb)
plot(S$fittedPredictedResponse , S$fittedResiduals)
plot(S$fittedPredictedResponse , S$scaledResiduals)

# mean - variance relationship
# Empirical mean - variance relationship :
Yhat = predict(Mlog_norm)
Q = quantile(Yhat, seq(0,1,length = nrow(ToHot)/3))
ToHot$grp = 1
for(q in Q[-1]){
  ToHot$grp[Yhat > q] = max(ToHot$grp)+1
}
boxplot(Suicide ~ grp, data = ToHot,log="y")
table(ToHot$grp)
EmpiricalMean_Variance = as.data.frame(t(sapply(unique(ToHot$grp), function(g){
  w=which(ToHot$grp==g)
  c('mean' = mean(ToHot$Suicide[w]), 'var' = var(ToHot$Suicide[w]))
  })))

plot(EmpiricalMean_Variance, log = 'xy')
# plot(log(EmpiricalMean_Variance), log = '')
Mnb$theta # https://stats.stackexchange.com/questions/460040/what-is-theta-in-negative-binomial-distribution
µ   = seq(min(EmpiricalMean_Variance$mean,na.rm = T), max(EmpiricalMean_Variance$mean,na.rm = T), length = 10000)
# points(log(µ),log(Var),type='l')
abline(0,1, lwd = 1.5) # poisson
points(µ , µ*overdisp(Mpoisson) , type ='l', col='darkgreen', lwd = 1.5) # quasipoisson
points(µ , µ+(µ^2)/Mnb$theta , type='l', col='darkred', lwd = 1.5) # negative binomial
legend(x = 'topleft',legend = c("Poisson","quasi-Poisson","negative binomial"), col=c('black', "darkgreen", "darkred"), text.col = c('black', "darkgreen", "darkred"), lwd = 1.5)
# mean - variance relationship



# fit.pois <- fitted(Mquasipoisson, type = "response")
# fit.nbin <- fitted(Mnb, type = "response")
# 
# cutq <- function(x, q = 10) {
#   quantile <- cut(x, breaks = quantile(x, probs = (0 : q) / q),
#   include.lowest = TRUE, labels = 1 : q)
#   quantile
# }
# 
# group <- cutq(fit.pois, q = 20)
# group <- cutq(fit.nbin, q = 20)
# group <- cutq(ToHot$Suicide, q = 20)
# qdat <- aggregate(ToHot$Suicide ,
#   list(group),
#   FUN = function(x) c(mean = mean(x), var = var(x)))
# qdat <- data.frame(qdat$x)
# qdat <- qdat[order(qdat$mean),]
# 
# phi <- summary(Mquasipoisson)$dispersion
# qdat$qvar <- phi * qdat$mean
# qdat$nbvar <- qdat$mean + (qdat$mean^2) / Mnb$theta
# head(qdat)
# 
# with(qdat, {
#   plot(var ~ mean, xlab = "Mean number of articles", ylab = "Variance", ylim = range(c(var , mean)),
#   pch = 16, cex = 1.2, cex.lab = 1.2,log='xy')
#   lines(mean, mean, col = gray(.40), lty = "dotted")
#   lines(mean, qvar, col = "red", lwd = 2)
#   lines(mean, nbvar, col = "blue", lwd = 2)
#   # lines(lowess(mean, var), lwd = 2, lty = "dashed")
#   legend(x = 'topleft',legend = c("Poisson","quasi-Poisson","negbin"), col=c(gray(.40), "red", "blue"), lty = c(3,1,1))
#  })

# /!\ tests multiples


plot(M)
plot(residuals(M) ~ predict(M))

summary(M)
overdisp(M)




M = glm(Suicide ~ TemperatureDeviationFromMean + I(TemperatureDeviationFromMean^2)
        ,data = ToHot, family = quasipoisson(link = 'log'))
summary(M)
overdisp(M)

M = glm(Suicide ~ TemperatureDeviationFromMean + I(TemperatureDeviationFromMean^2)
        ,data = ToHot)

glm.nb



library(lme4)
library(afex)

M = mixed(Suicide ~ TemperatureDeviationFromMean + I(TemperatureDeviationFromMean^2) + (1|Country) ,data = ToHot,method = 'KR')
anova(M)

M = mixed(Suicide ~ TemperatureDeviationFromMean + (1|Country) ,data = ToHot, method = 'LRT', family=poisson(link = 'log'))
anova(M)

M = glmer(Suicide ~ TemperatureDeviationFromMean + (1|Country) ,data = ToHot, family=poisson(link = 'log'))
overdisp(M)

M = glmer.nb(Suicide ~ TemperatureDeviationFromMean + (1|Country) ,data = ToHot)
overdisp(M)
summary(M)
anova(M)



